# Session 1 setup guide: Mac and Windows

**Time needed: about 15 minutes.** Please do this **before** Session 1 if you can. Then we spend class time coding, not installing. If anything goes wrong, don't worry: we'll fix it together at the start of class (we've allowed time for it).

**You'll also need the course kit, `session1_kit.zip`.** It is attached to the email this guide came with (we'll also have it on a USB stick in class). It contains the notebook and the data. Save it somewhere easy to find, like your Downloads folder.

You are installing three things:

| What | Why |
|---|---|
| **Python** | the programming language itself |
| **VS Code** | the editor where you write and run code (free, from Microsoft) |
| **Two VS Code extensions** (Python and Jupyter) | let VS Code run *notebooks*: documents that mix text and runnable code |

Then you'll open the course kit and run one cell to confirm everything works.

> **Can't install software** (a work or uni-managed laptop that blocks installs)? Skip to **Plan B** at the bottom. You can still do the whole course in your browser.

---

## Step 1: Install Python

Go to <https://www.python.org/downloads/> and click the big yellow **Download Python 3.13** button (any newer version is fine).

### Mac
1. Open the downloaded **`.pkg`** file.
2. Click **Continue → Agree → Install**. Enter your Mac password if asked.
3. When it says "The installation was successful", click **Close**.

### Windows
1. Open the downloaded **`.exe`** file.
2. ✅ **On the very first screen, tick "Add python.exe to PATH"** (tick-box at the bottom). *This is the most common thing people miss.*
3. Click **Install Now → Yes → Close**.

---

## Step 2: Install VS Code

Go to <https://code.visualstudio.com/> and click the **Download** button.

### Mac
1. You'll get a `.zip` file. Double-click it to unzip.
2. Drag **Visual Studio Code** into your **Applications** folder.
3. Open it from Applications. (If Mac says it "can't be opened because Apple cannot check it", right-click the app → **Open** → **Open**.)

### Windows
1. Run the downloaded installer and accept the agreement.
2. On "Select Additional Tasks", tick **Add to PATH** and both **"Open with Code"** options.
3. Click **Install → Finish**. VS Code opens.

---

## Step 3: Open the course folder and add two extensions

1. **Find the course kit** (`session1_kit.zip`, attached to our email) and **unzip it** and put the `session1_kit` folder somewhere easy, such as Documents.
   - **Mac:** double-click the zip.
   - **Windows:** right-click the zip → **Extract All…**
2. In VS Code: **File → Open Folder…** → choose the `session1_kit` folder → click **Yes, I trust the authors**.
3. Click the **Extensions** icon in the left sidebar (it looks like four squares), or press **⇧⌘X** (Mac) / **Ctrl+Shift+X** (Windows).
4. Search for **Python** → click **Install** on the one published by **Microsoft**.
5. Search for **Jupyter** → click **Install** on the one published by **Microsoft**.

You should now see these files listed on the left: `session1_asx_stock_explorer_starter.ipynb`, `data`, `requirements.txt`, `START_HERE.txt`.

---

## Step 4: Create your Python environment

This makes a private "box" of libraries (pandas, matplotlib, …) just for this course, and installs them for you.

1. Open the **Command Palette**: press **⇧⌘P** (Mac) or **Ctrl+Shift+P** (Windows).
2. Type **`Python: Create Environment`** and press Enter.
3. Choose **Venv**.
4. Choose the Python you installed in Step 1 (e.g. *Python 3.13*).
5. **Tick `requirements.txt`**, then click **OK**.
6. Wait **1–3 minutes**. A message in the bottom-right says it's creating the environment. When a `.venv` folder appears in the file list, it's done.

---

## Step 5: Open the notebook and run the first cell

1. Click **`session1_asx_stock_explorer_starter.ipynb`** in the file list.
2. At the top right, click **Select Kernel** → **Python Environments…** → choose **`.venv`**.
   *(If it offers to install "ipykernel", click **Install**.)*
3. Click inside the **first code cell** (the grey box starting with `# ▶ Run this cell first`).
4. Press **Shift + Enter** (or click the ▶ button to the left of the cell).

✅ **Success looks like:** `✅ Ready. Files available: ['data/prices.csv', 'data/cba_ohlcv.csv']`

You're done! Close VS Code and see you in class.

---

## If something goes wrong

| What you see | What to do |
|---|---|
| **Windows:** "python is not recognised" | Re-run the Python installer → **Modify/Repair** or reinstall, and **tick "Add python.exe to PATH"**. Then restart VS Code |
| `Python: Create Environment` doesn't list your Python | Restart VS Code. Still missing? Press ⇧⌘P / Ctrl+Shift+P → **Python: Select Interpreter** → pick it |
| **Select Kernel** doesn't show `.venv` | Press ⇧⌘P / Ctrl+Shift+P → **Developer: Reload Window**, then try Select Kernel again |
| **Mac:** an app "cannot be opened" | Right-click the app → **Open** → **Open** |
| The environment step is very slow | It downloads libraries, so it depends on your wifi. Give it a few minutes |
| You ran the cell and see an error | Copy the **last line** of the error and message it to us |
| Anything else | Take a screenshot and message us. **Asking early is a skill.** |

## Plan B: no installs needed (works on any laptop)

1. Go to <https://colab.research.google.com> and sign in with a Google account.
2. **File → Upload notebook** → choose `session1_asx_stock_explorer_starter.ipynb`.
3. Click the **📁 Files** icon on the left → drag the **`data`** folder from the kit into it. (Wait for the upload to finish.)
4. Run the first cell with **Shift + Enter**. You should see `✅ Ready`.

Everything in class works the same way in Colab.
